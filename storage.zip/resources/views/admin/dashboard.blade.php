<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
    </x-slot>

    <livewire:admin.dashboard />
</x-admin-layout>
