<x-admin-layout>
    <livewire:admin.service-management />
</x-admin-layout>
