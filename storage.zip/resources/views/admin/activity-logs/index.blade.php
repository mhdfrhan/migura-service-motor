<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Activity Logs</h1>
    </x-slot>

    <livewire:admin.activity-logs />
</x-admin-layout>

