<x-admin-layout>
    <livewire:admin.staff-performance />
</x-admin-layout>

