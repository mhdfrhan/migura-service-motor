<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Kelola Booking</h1>
    </x-slot>

    <livewire:admin.booking-management />
</x-admin-layout>
