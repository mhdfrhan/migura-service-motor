<x-admin-layout>
    <livewire:admin.location-management />
</x-admin-layout>
