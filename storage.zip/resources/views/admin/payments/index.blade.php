<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Verifikasi Pembayaran</h1>
    </x-slot>

    <livewire:admin.payment-verification />
</x-admin-layout>
