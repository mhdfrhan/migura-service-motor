<x-admin-layout>
    <livewire:admin.customer-management />
</x-admin-layout>
