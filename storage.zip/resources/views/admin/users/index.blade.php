<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Kelola User</h1>
    </x-slot>

    <livewire:admin.user-management />
</x-admin-layout>

