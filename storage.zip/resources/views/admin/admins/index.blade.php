<x-admin-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Kelola Admin</h1>
    </x-slot>

    <livewire:admin.admin-management />
</x-admin-layout>
