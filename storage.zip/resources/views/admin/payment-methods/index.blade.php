<x-admin-layout>
    <x-slot name="header">
        <h2 class="text-2xl font-bold text-gray-800">
            Metode Pembayaran
        </h2>
    </x-slot>

    <livewire:admin.payment-method-management />
</x-admin-layout>
