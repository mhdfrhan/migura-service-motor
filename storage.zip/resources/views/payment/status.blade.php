<x-main-layout>
    <x-slot name="title">Status Pembayaran</x-slot>

</x-main-layout>

