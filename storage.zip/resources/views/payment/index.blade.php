<x-main-layout>
    <x-slot name="title">Pembayaran</x-slot>

</x-main-layout>

