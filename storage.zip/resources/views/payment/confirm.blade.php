<x-main-layout>
    <x-slot name="title">Konfirmasi Pembayaran</x-slot>

    <livewire:payment-confirmation />
</x-main-layout>

