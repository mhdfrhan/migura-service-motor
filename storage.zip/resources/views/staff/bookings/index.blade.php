<x-staff-layout>
    <x-slot name="header">
        <h1 class="text-2xl font-bold text-gray-900">Booking Saya</h1>
    </x-slot>

    <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 class="text-xl font-bold text-gray-900 mb-4">Daftar Booking</h3>
        <p class="text-gray-600">Halaman ini akan menampilkan daftar booking yang ditugaskan kepada Anda.</p>
    </div>
</x-staff-layout>

