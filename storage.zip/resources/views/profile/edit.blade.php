<x-main-layout>
    <x-slot name="title">Edit Profil</x-slot>

    <livewire:edit-profile />
</x-main-layout>
