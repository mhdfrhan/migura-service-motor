<x-main-layout>
    <x-slot name="title">Profil</x-slot>

</x-main-layout>
