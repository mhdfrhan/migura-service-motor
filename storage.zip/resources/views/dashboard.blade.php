<x-main-layout>
    <x-slot name="title">Dashboard</x-slot>

    <livewire:customer-dashboard />
</x-main-layout>
