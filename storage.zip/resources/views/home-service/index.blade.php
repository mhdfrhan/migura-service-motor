<x-main-layout>
    <x-slot name="title">Home Service</x-slot>

    <livewire:home-service />
</x-main-layout>
