<x-main-layout>
    <x-slot name="title">Konfirmasi Reservasi</x-slot>

</x-main-layout>

