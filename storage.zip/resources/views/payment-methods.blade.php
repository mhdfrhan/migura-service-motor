<x-main-layout>
    <x-slot name="title">Metode Pembayaran</x-slot>

    <livewire:payment-methods />
</x-main-layout>
