<x-main-layout>
    <x-slot name="title">Bantuan & Dukungan</x-slot>

    <livewire:help-support />
</x-main-layout>
