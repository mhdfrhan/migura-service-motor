<x-main-layout>
    <x-slot name="title">Notifikasi</x-slot>

    <div class="min-h-screen bg-gray-50 pb-20">
        <livewire:all-notifications />
    </div>
</x-main-layout>
